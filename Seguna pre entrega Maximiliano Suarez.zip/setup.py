from setuptools import setup, find_packages

setup(
    name='mi_paquete',
    version='1.0',
    description='Segunda pre-entrega',
    author='Maxi Suarez',
    package=find_packages,
    author_email="taki-s4@hotmail.com"
)