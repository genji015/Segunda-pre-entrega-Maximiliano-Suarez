from cliente import Cliente
def mostrar_menu():
    print("\nMenú de Opciones:")
    print("1. Crear nuevo cliente")
    print("2. Mostrar información del cliente")
    print("3. Actualizar email del cliente")
    print("4. Salir")

def main():
    cliente = None

    while True:
        mostrar_menu()
        opcion = input("Selecciona una opción: ")

        if opcion == '1':
            nombre = input("Introduce el nombre: ")
            apellido = input("Introduce el apellido: ")
            email = input("Introduce el email: ")
            telefono = input("Introduce el teléfono: ")
            cliente = Cliente(nombre, apellido, email, telefono)
            print("Cliente creado con éxito.")

        elif opcion == '2':
            if cliente:
                print(cliente.mostrar_informacion())
            else:
                print("No hay cliente registrado.")

        elif opcion == '3':
            if cliente:
                nuevo_email = input("Introduce el nuevo email: ")
                print(cliente.actualizar_email(nuevo_email))
            else:
                print("No hay cliente registrado.")

        elif opcion == '4':
            print("Saliendo del programa. ¡Adiós!")
            break

        else:
            print("Opción no válida. Inténtalo de nuevo.")

if __name__ == "__main__":
    main()